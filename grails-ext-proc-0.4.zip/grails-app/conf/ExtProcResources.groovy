modules = {
	extproc {
		dependsOn 'jquery'
		defaultBundle 'extproc-ui'
	
		resource url:'js/extproc.js', attrs:[type:'js']
	}

}
